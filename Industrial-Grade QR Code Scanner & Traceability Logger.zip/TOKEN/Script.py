import qrcode
import openpyxl
from openpyxl.drawing.image import Image
from datetime import datetime
import os

# Parameters
file_name = "scanned_data.xlsx"
backup_file = "scanned_backup.txt"
product_ref_prefix = "VPRR1F"

# Load or create Excel workbook
if os.path.exists(file_name):
    wb = openpyxl.load_workbook(file_name)
    ws = wb.active
else:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["N°", "Date", "Scan", "QR Code"])

# Read existing scans from Excel
existing_scans = set()
for row in ws.iter_rows(min_row=2, values_only=True):
    if row[2]:
        existing_scans.add(row[2])

# Also read scans from backup file (to persist across sessions)
if os.path.exists(backup_file):
    with open(backup_file, "r") as f:
        for line in f:
            code = line.strip()
            if code:
                existing_scans.add(code)

# Prepare QR codes folder
qr_folder = "qr_codes"
os.makedirs(qr_folder, exist_ok=True)

current_row = ws.max_row

print("📷 Scanner prêt. Appuie sur [Entrée] sans texte pour quitter.\n")

while True:
    scan_input = input("→ Scan  ").strip()

    if scan_input == "":
        print("⛔ Fin du scan.")
        break

    if not scan_input.startswith(product_ref_prefix):
        print(f"⚠️ Scan rejeté : doit commencer par '{product_ref_prefix}'")
        continue

    if scan_input in existing_scans:
        print("⚠️ Scan déjà enregistré.")
        continue

    # Generate QR code image
    qr_img = qrcode.make(scan_input)
    qr_filename = os.path.join(qr_folder, f"qr_{current_row}.png")
    qr_img.save(qr_filename)

    # Save data to Excel
    current_row += 1
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ws.cell(row=current_row, column=1).value = current_row - 1
    ws.cell(row=current_row, column=2).value = now
    ws.cell(row=current_row, column=3).value = scan_input

    # Insert QR code image in column D
    img = Image(qr_filename)
    img.width, img.height = 100, 100
    ws.add_image(img, f"D{current_row}")

    # Adjust row height and column width for better display
    ws.row_dimensions[current_row].height = 80
    ws.column_dimensions["D"].width = 15

    existing_scans.add(scan_input)

    # Save backup file immediately
    with open(backup_file, "a") as f:
        f.write(scan_input + "\n")

    # Save Excel file immediately after each scan
    wb.save(file_name)

    print(f"✅ Enregistré  {scan_input}")

print(f"📁 Données enregistrées dans '{file_name}' et sauvegarde '{backup_file}'")
